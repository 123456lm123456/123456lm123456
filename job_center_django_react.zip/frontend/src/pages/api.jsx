import axios from 'axios';

const BASE_URL = 'http://127.0.0.1:8000/api/';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 5000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Authentication API calls
export const loginUser = async (username, password) => {
  try {
    const response = await api.post('login/', { username, password });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const fetchJobs = async (token) => {
  try {
    const response = await api.get('jobs/all/', {
      headers: { Authorization: `JWT ${token}` },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createJob = async (token, newData) => {
    try {
      const response = await api.post('jobs/', newData, {
        headers: {
          Authorization: `JWT ${token}`,
          'Content-Type': 'application/json',
        },
      });
      return response.data;
    } catch (error) {
      throw error;
    }
};

export const getJob = async (token, jobId) => {
  try {
    const response = await api.get(`job_detail/${jobId}/`, {
      headers: { Authorization: `JWT ${token}` },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};


export const deleteJob = async (token, jobId) => {
  try {
    const response = await api.delete(`job_detail/${jobId}/`, {
      headers: { Authorization: `JWT ${token}` },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const sendRequestWithResume = async (token, jobId, formData) => {
  try {
    const response = await api.post(`job_detail/${jobId}/send_request/`, formData, {
      headers: {
        Authorization: `JWT ${token}`,
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export default api;