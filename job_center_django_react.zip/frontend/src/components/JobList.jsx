import React, { useState, useEffect } from 'react';
import { fetchJobs, createJob, deleteJob, sendRequestWithResume } from '../pages/api';
import { Modal, Button, Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

const JobList = ({ token, isSuperuser }) => {
  const [jobs, setJobs] = useState([]);
  const [newjob, setNewJob] = useState({ title: '', description: '' });
  const [selectedJob, setSelectedJob] = useState(null);

  const fetchUserJobs = async () => {
    try {
      const jobsData = await fetchJobs(token);
      setJobs(jobsData);
    } catch (error) {
      console.error('Fetch jobs error:', error);
    }
  };

  useEffect(() => {
    if (token) {
      fetchUserJobs();
    }
  }, [token]);

  const handleCreateJob = async () => {
    try {
      await createJob(token, newjob);
      setNewJob({ title: '', description: '' });
      fetchUserJobs();
    } catch (error) {
      console.error('Create Job error:', error);
    }
  };

  const handleDeleteJob = async (jobId) => {
    try {
      await deleteJob(token, jobId);
      fetchUserJobs();
    } catch (error) {
      console.error('Delete Job error:', error);
    }
  };

  const handleSendRequest = async (jobId) => {
    try {
      const formData = new FormData();
      formData.append('resume', document.getElementById('formResume').files[0]);

      await sendRequestWithResume(token, jobId, formData);

      setSelectedJob(null);
      fetchUserJobs();
    } catch (error) {
      console.error('Send Request error:', error);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">Jobs</h2>
      <div className="row">
        {jobs.map((job) => (
          <div key={job.id} className="col-md-6 mb-4">
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">{job.title}</h5>
                <p className="card-text">{job.description}</p>
                <div className="text-right">
                  {isSuperuser ? (
                    <button className="btn btn-danger" onClick={() => handleDeleteJob(job.id)}>Delete</button>
                  ) : (
                    <button className="btn btn-primary" onClick={() => setSelectedJob(job)}>Send Request</button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {isSuperuser && (
        <div>
          <hr />
          <h3 className="text-center mb-4">Create Job</h3>
          <div className="form-group">
            <input
              type="text"
              placeholder="Title"
              value={newjob.title}
              className='form-control mb-2 text-center'
              onChange={(e) => setNewJob({ ...newjob, title: e.target.value })}
            />
            <input
              type="text"
              placeholder="Description..."
              value={newjob.description}
              className='form-control text-center' 
              style={{ height: '200px' }}
              onChange={(e) => setNewJob({ ...newjob, description: e.target.value })}
            />
          </div>
          <div className='text-center mb-5'>
            <button className='btn btn-success mt-3' onClick={handleCreateJob}>Create Job</button>
          </div>
        </div>
      )}

      {/* Modal for sending a request */}
      <Modal show={selectedJob !== null} onHide={() => setSelectedJob(null)}>
        <Modal.Header closeButton>
          <Modal.Title>Send Request</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="formResume">
              <Form.Label>Resume</Form.Label>
              <Form.Control type="file" accept=".pdf,.doc,.docx" />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setSelectedJob(null)}>
            Close
          </Button>
          <Button variant="primary" onClick={() => handleSendRequest(selectedJob.id)}>
            Send Request
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default JobList;
