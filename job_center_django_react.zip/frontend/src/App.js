import React, { useState, useEffect } from 'react';
import Login from './components/Login';
import { getToken, removeToken } from './pages/auth';
import JobList from './components/JobList';
import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {
  const [token, setToken] = useState(getToken());
  const [isSuperuser, setIsSuperuser] = useState(false);

  useEffect(() => {
    if (token) {
      const decodedToken = parseJwt(token);
      setIsSuperuser(decodedToken && decodedToken.is_superuser === true);
    }
  }, [token]);

  const handleLogin = () => {
    setToken(getToken());
  };

  const handleLogout = () => {
    removeToken();
    setToken(null);
  };

  // Helper function to decode JWT token
  const parseJwt = (token) => {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace('-', '+').replace('_', '/');
      return JSON.parse(atob(base64));
    } catch (error) {
      return null;
    }
  };

  return (
    <div className="container">
      <h1 className="mt-3 mb-5 text-center">Job Hub</h1>
      {token ? (
        <div>
          <button className="btn btn-danger mb-5" onClick={handleLogout}>
            Logout
          </button>
          <JobList token={token} isSuperuser={isSuperuser} />
        </div>
      ) : (
        <Login onLogin={handleLogin} />
      )}
    </div>
  );
};

export default App;
